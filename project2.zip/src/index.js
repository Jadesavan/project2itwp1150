import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import HighLow from "./highlow";


ReactDOM.render(
    <HighLow />,
    document.querySelector("#container")
);